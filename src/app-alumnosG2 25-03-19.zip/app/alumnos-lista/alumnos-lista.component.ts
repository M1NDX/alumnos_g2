import { Component, OnInit } from '@angular/core';
import { Alumno } from '../alumno/Alumno';
import { AlumnosService } from '../alumnos.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-alumnos-lista',
  templateUrl: './alumnos-lista.component.html',
  styleUrls: ['./alumnos-lista.component.css']
})
export class AlumnosListaComponent implements OnInit {
  alumnos: Alumno[];
  subscript: Subscription;


  constructor(private alumnoService: AlumnosService ) { }

  ngOnInit() {
      this.alumnos= this.alumnoService.getAlumnos();
      this.subscript = this.alumnoService.cambiaDato
      .subscribe(
        (arregloAlumnos: Alumno[]) => {
          this.alumnos = arregloAlumnos;
        }
      );

  }

  editar(alumno){
    console.log(`El alumno a editar id: ${alumno.id} nombre: ${alumno.nombre}`);
  }

  borrar(id: number) {
    this.alumnoService.borrarAlumno(id);
    //this.alumnos= this.alumnoService.getAlumnos();
 
  }
}
