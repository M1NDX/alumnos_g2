import { Component, OnInit } from '@angular/core';
import { Alumno } from './Alumno';

@Component({
  selector: 'app-alumno',
  templateUrl: './alumno.component.html',
  styleUrls: ['./alumno.component.css']
})
export class AlumnoComponent implements OnInit {

  alumno: Alumno = {
    id: 1,
    nombre: 'Miguel',
    edad: 23,
    calificacion: 85,
    carrera: 'ISC',
    sexo: 'M'
  };

  constructor() { }

  ngOnInit() {
  }

  borrarAlumno() {
    console.log('se borrará ' + this.alumno.nombre);
  }

}
