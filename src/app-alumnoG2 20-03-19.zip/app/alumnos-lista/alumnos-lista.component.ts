import { Component, OnInit } from '@angular/core';
import { Alumno } from '../alumno/Alumno';

@Component({
  selector: 'app-alumnos-lista',
  templateUrl: './alumnos-lista.component.html',
  styleUrls: ['./alumnos-lista.component.css']
})
export class AlumnosListaComponent implements OnInit {
  alumnos: Alumno[] = [
    {
      id: 1,
      nombre: 'Miguel',
      edad: 23,
      calificacion: 85,
      carrera: 'ISC',
      sexo: 'M'
    },
    {
      id: 2,
      nombre: 'Adriana',
      edad: 25,
      calificacion: 56,
      carrera: 'ISC',
      sexo: 'F'
    },
    {
      id: 3,
      nombre: 'Alejandra',
      edad: 22,
      calificacion: 58,
      carrera: 'ISC',
      sexo: 'F'
    }

  ];
  constructor() { }

  ngOnInit() {
  }

  editar(alumno){
    console.log(`El alumno a editar id: ${alumno.id} nombre: ${alumno.nombre}`);
  }
}
